﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TAL.PremiumCalculator.Services.Model
{
    public class Member
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [MaxLength(150, ErrorMessage = "Name must be 150 characters or less")]
        public string Name { get; set; }
        [Required]
        public DateTime DateOfBirth { get; set; }
        [ForeignKey("Occupation")]
        public int OccupationId { get; set; }
    }
}
