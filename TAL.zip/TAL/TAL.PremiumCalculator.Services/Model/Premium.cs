﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TAL.PremiumCalculator.Services.Model
{
    public class Premium
    {
        public decimal PremiumValue { get; set; }
    }
}
