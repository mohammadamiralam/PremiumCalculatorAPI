﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TAL.PremiumCalculator.Services.Migrations
{
    public partial class AddedOcupationId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Members",
                keyColumn: "Id",
                keyValue: 1,
                column: "OccupationId",
                value: 1);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Members",
                keyColumn: "Id",
                keyValue: 1,
                column: "OccupationId",
                value: 0);
        }
    }
}
