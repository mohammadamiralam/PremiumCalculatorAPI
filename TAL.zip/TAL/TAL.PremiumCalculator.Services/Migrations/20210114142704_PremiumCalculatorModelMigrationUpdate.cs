﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TAL.PremiumCalculator.Services.Migrations
{
    public partial class PremiumCalculatorModelMigrationUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DeathInsuredMembers_Members_MemberId",
                table: "DeathInsuredMembers");

            migrationBuilder.DropPrimaryKey(
                name: "PK_DeathInsuredMembers",
                table: "DeathInsuredMembers");

            migrationBuilder.RenameTable(
                name: "DeathInsuredMembers",
                newName: "DeathInsured");

            migrationBuilder.RenameIndex(
                name: "IX_DeathInsuredMembers_MemberId",
                table: "DeathInsured",
                newName: "IX_DeathInsured_MemberId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_DeathInsured",
                table: "DeathInsured",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_DeathInsured_Members_MemberId",
                table: "DeathInsured",
                column: "MemberId",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_DeathInsured_Members_MemberId",
                table: "DeathInsured");

            migrationBuilder.DropPrimaryKey(
                name: "PK_DeathInsured",
                table: "DeathInsured");

            migrationBuilder.RenameTable(
                name: "DeathInsured",
                newName: "DeathInsuredMembers");

            migrationBuilder.RenameIndex(
                name: "IX_DeathInsured_MemberId",
                table: "DeathInsuredMembers",
                newName: "IX_DeathInsuredMembers_MemberId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_DeathInsuredMembers",
                table: "DeathInsuredMembers",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_DeathInsuredMembers_Members_MemberId",
                table: "DeathInsuredMembers",
                column: "MemberId",
                principalTable: "Members",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
