﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TAL.PremiumCalculator.Services.Migrations
{
    public partial class seeddata : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Members",
                columns: new[] { "Id", "DateOfBirth", "Name" },
                values: new object[] { 1, new DateTime(1992, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "John W." });

            migrationBuilder.InsertData(
                table: "Ratings",
                columns: new[] { "Id", "Factor", "Name" },
                values: new object[,]
                {
                    { 1, 1m, "Professional" },
                    { 2, 1.25m, "White Collar" },
                    { 3, 1.5m, "Light Manual" },
                    { 4, 1.75m, "Heavy Manual" }
                });

            migrationBuilder.InsertData(
                table: "Occupations",
                columns: new[] { "Id", "Name", "RatingId" },
                values: new object[,]
                {
                    { 2, "Doctor", 1 },
                    { 3, "Author", 2 },
                    { 1, "Cleaner", 3 },
                    { 6, "Florist", 3 },
                    { 4, "Farmer", 4 },
                    { 5, "Mechanic", 4 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Members",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Occupations",
                keyColumn: "Id",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Ratings",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Ratings",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Ratings",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Ratings",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
