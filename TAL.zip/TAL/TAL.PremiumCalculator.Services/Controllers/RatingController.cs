﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RatingController : ControllerBase
    {
        private readonly IRatingRepository _ratingRepository;

        public RatingController(IRatingRepository ratingRepository)
        {
            _ratingRepository = ratingRepository;
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Rating>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Rating>>> GetRatings()
        {
            var ratings = await _ratingRepository.GetRatings();
            return Ok(ratings);
        }
    }
}
