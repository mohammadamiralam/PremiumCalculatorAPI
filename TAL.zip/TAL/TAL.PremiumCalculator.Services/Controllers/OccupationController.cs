﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OccupationController : ControllerBase
    {
        private readonly IOccupationRepository _occupationRepo;

        public OccupationController(IOccupationRepository occupationRepo)
        {
            _occupationRepo = occupationRepo;
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Occupation>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Occupation>>> GetOccupations()
        {
            var occupation = await _occupationRepo.GetOccupations();
            return Ok(occupation);
        }
    }
}
