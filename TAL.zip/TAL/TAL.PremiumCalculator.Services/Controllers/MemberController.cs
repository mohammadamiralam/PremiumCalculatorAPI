﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private readonly IMemberRepository _member;

        public MemberController(IMemberRepository member)
        {
            _member = member;
        }

        [HttpGet("GetMember")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(Member), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<Product>> GetMemberById(int Id)
        {
            var member = await _member.GetMember(Id);

            if (member == null)
            {
                return NotFound();
            }

            return Ok(member);
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Member>), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<IEnumerable<Member>>> GetMembers()
        {
            var members = await _member.GetMembers();
            return Ok(members);
        }


        [HttpPost]
        [ProducesResponseType(typeof(Member), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<Member>> SaveMember([FromBody] Member member)
        {
            await _member.SaveMember(member);

            return Ok();
        }
    }
}
