﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Model;

namespace TAL.PremiumCalculator.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PremiumController : ControllerBase
    {
        public PremiumController()
        {

        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Premium>), (int)HttpStatusCode.OK)]
        public ActionResult<Premium> GetMonthlyPremium(int age, decimal factor, decimal SumInsured)
        {

            var premium = (SumInsured * factor *age) / 1000 * 12;

            var premiumObj = new Premium();
            premiumObj.PremiumValue = premium;
            OkObjectResult okObjectResult = Ok(premiumObj);
            return okObjectResult;
        }
    }
}
