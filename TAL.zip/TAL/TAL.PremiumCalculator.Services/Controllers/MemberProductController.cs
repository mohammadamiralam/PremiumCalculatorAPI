﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberProductController : ControllerBase
    {
        private readonly IMemberProductRepository _memberProduct;

        public MemberProductController(IMemberProductRepository memberProduct)
        {
            _memberProduct = memberProduct;
        }

        [HttpGet]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(Member), (int)HttpStatusCode.OK)]
        public async Task<ActionResult<Product>> GetMemberById(int Id)
        {
            var memberProductInfo = await _memberProduct.GetMemberProduct(Id);

            if (memberProductInfo == null)
            {
                return NotFound();
            }

            return Ok(memberProductInfo);
        }
    }
}
