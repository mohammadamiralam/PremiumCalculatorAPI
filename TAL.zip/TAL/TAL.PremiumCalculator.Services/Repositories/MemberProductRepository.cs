﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Context.Interface;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Repositories
{
    public class MemberProductRepository : IMemberProductRepository
    {
        private readonly IPremiumCalculatorContext _context;
        public MemberProductRepository(IPremiumCalculatorContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }
        public async Task<MemberProductInfo> GetMemberProduct(int memberId)
        {
            try
            {
                var memberProductInfo = await _context
                    .MemberProductInfos
                    .FirstOrDefaultAsync(x => x.Id.Equals(memberId));
                return memberProductInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
