﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Model;

namespace TAL.PremiumCalculator.Services.Repositories.Interfaces
{
    public interface IOccupationRepository
    {
        Task<IEnumerable<Occupation>> GetOccupations();
    }
}
