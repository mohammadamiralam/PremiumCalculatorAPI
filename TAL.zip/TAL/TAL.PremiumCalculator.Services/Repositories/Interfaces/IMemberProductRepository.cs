﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Model;

namespace TAL.PremiumCalculator.Services.Repositories.Interfaces
{
    public interface IMemberProductRepository
    {
        Task<MemberProductInfo> GetMemberProduct(int memberId);
    }
}
