﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Context.Interface;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Repositories
{
    public class MemberRepository : IMemberRepository
    {
        private readonly IPremiumCalculatorContext _context;
        public MemberRepository(IPremiumCalculatorContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }
        public async Task<Member> GetMember(int memberId)
        {
            try
            {
                var member = await _context
                    .Members
                    .FirstOrDefaultAsync(x => x.Id.Equals(memberId));
                return member;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Member>> GetMembers()
        {

            try
            {
                var members = await _context
                    .Members
                    .ToListAsync();
                return members;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task SaveMember(Member member)
        {
            try
            {
                await _context.Members.AddAsync(member);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }

}
