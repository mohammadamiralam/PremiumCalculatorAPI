﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Context.Interface;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Repositories
{
    public class OccupationRepository : IOccupationRepository
    {
        private readonly IPremiumCalculatorContext _context;
        public OccupationRepository(IPremiumCalculatorContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }
        public async Task<IEnumerable<Occupation>> GetOccupations()
        {
            try
            {
                var occupation = await _context
                    .Occupations
                    .ToListAsync();
                return occupation;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
