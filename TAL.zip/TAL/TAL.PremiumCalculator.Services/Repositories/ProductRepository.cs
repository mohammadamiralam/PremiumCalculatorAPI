﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Context.Interface;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly IPremiumCalculatorContext _context;
        public ProductRepository(IPremiumCalculatorContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }
        public async Task<IEnumerable<Product>> GetProducts()
        {
            try
            {
                var products = await _context
                    .Products
                    .ToListAsync();
                return products;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
