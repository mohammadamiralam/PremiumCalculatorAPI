﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Context.Interface;
using TAL.PremiumCalculator.Services.Model;
using TAL.PremiumCalculator.Services.Repositories.Interfaces;

namespace TAL.PremiumCalculator.Services.Repositories
{
    public class RatingRepository : IRatingRepository
    {
        private readonly IPremiumCalculatorContext _context;
        public RatingRepository(IPremiumCalculatorContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }
        public async Task<IEnumerable<Rating>> GetRatings()
        {
            try
            {
                var ratings = await _context
                    .Ratings
                    .ToListAsync();
                return ratings;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
