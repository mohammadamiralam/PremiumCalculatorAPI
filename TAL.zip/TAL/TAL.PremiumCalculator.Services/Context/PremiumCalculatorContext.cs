﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Context.Interface;
using TAL.PremiumCalculator.Services.Model;

namespace TAL.PremiumCalculator.Services.Context
{
    public class PremiumCalculatorContext : DbContext, IPremiumCalculatorContext
    {
        public PremiumCalculatorContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Member> Members { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<MemberProductInfo> MemberProductInfos { get; set; }
        public DbSet<Occupation> Occupations { get; set; }
        public DbSet<Rating> Ratings { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Member>().HasData(
                new Member() {Id =1, DateOfBirth = Convert.ToDateTime("01/01/1992"), Name = "John W." ,OccupationId=1});

            modelBuilder.Entity<Product>().HasData(
               new Product() { Id = 1, SumInsured = Convert.ToDecimal("1000000"), Name = "Death Insurance" });

            modelBuilder.Entity<MemberProductInfo>().HasData(
              new MemberProductInfo() { Id = 1, MemberId = 1, ProductId = 1 });

            modelBuilder.Entity<Occupation>().HasData(
               new Occupation() { Id = 1, RatingId = 3, Name = "Cleaner" },
               new Occupation() { Id = 2, RatingId = 1, Name = "Doctor" },
               new Occupation() { Id = 3, RatingId = 2, Name = "Author" },
               new Occupation() { Id = 4, RatingId = 4, Name = "Farmer" },
               new Occupation() { Id = 5, RatingId = 4, Name = "Mechanic" },
               new Occupation() { Id = 6, RatingId = 3, Name = "Florist" });

            modelBuilder.Entity<Rating>().HasData(
              new Rating() { Id = 1, Factor = Convert.ToDecimal(1.0), Name = "Professional" },
              new Rating() { Id = 2, Factor = Convert.ToDecimal(1.25), Name = "White Collar" },
              new Rating() { Id = 3, Factor = Convert.ToDecimal(1.50), Name = "Light Manual" },
              new Rating() { Id = 4, Factor = Convert.ToDecimal(1.75), Name = "Heavy Manual" });
        }
    }
}
