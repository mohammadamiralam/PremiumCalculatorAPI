﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TAL.PremiumCalculator.Services.Model;

namespace TAL.PremiumCalculator.Services.Context.Interface
{
    public interface IPremiumCalculatorContext
    {
        DbSet<Member> Members { get; set; }
        DbSet<Product> Products { get; set; }
        DbSet<MemberProductInfo> MemberProductInfos { get; set; }
        DbSet<Occupation> Occupations { get; set; }
        DbSet<Rating> Ratings { get; set; }
    }
}
